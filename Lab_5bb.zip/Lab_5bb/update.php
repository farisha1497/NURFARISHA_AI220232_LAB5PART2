<?php
if (isset($_GET['matric'])) {
    $conn = new mysqli('localhost', 'root', '', 'Lab_5b');
    if ($conn->connect_error) {
        die('Connection failed: ' . $conn->connect_error);
    }

    $matric = $_GET['matric'];
    $result = $conn->query("SELECT * FROM users WHERE matric = '$matric'");
    $user = $result->fetch_assoc();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $name = $_POST['name'];
        $role = $_POST['role'];

        $stmt = $conn->prepare("UPDATE users SET name = ?, role = ? WHERE matric = ?");
        $stmt->bind_param('sss', $name, $role, $matric);
        if ($stmt->execute()) {
            header('Location: user_list.php');
        } else {
            echo 'Error updating user.';
        }

        $stmt->close();
    }
    $conn->close();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Update User</title>
</head>
<body>
    <h1>Update User</h1><br>
    <form method="POST">
        <label>Matric </label><input type="text" name="matric" value="<?php echo $user['matric']; ?>" required><br>
        <label>Name </label><input type="text" name="name" value="<?php echo $user['name']; ?>" required><br>
        <label>Access Level </label>
        <select name="role">
            <option value="student" <?php if ($user['role'] == 'student') echo 'selected'; ?>>Student</option>
            <option value="lecturer" <?php if ($user['role'] == 'lecturer') echo 'selected'; ?>>Lecturer</option>
        </select><br>
        <button type="submit">Update</button>
        <a href="user_list.php">Cancel</a>
    </form>
</body>
</html>
