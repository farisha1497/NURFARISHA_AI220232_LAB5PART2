<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_delete'])) {
    $conn = new mysqli('localhost', 'root', '', 'Lab_5b');
    if ($conn->connect_error) {
        die('Connection failed: ' . $conn->connect_error);
    }

    $stmt = $conn->prepare("DELETE FROM users WHERE matric = ?");
    $stmt->bind_param('s', $_POST['matric']);

    if ($stmt->execute()) {
        echo 'User deleted successfully!';
        header('Location: user_list.php');
        exit(); // Ensure no further script is executed after the redirect
    } else {
        echo 'Error: ' . $stmt->error;
    }

    $stmt->close();
    $conn->close();
} elseif (isset($_GET['matric'])) {
    $matric = $_GET['matric'];
} else {
    echo 'No matric provided for deletion.';
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Delete User</title>
</head>
<body>
    <h1>Delete User</h1>
    <p>Are you sure you want to delete the user with Matric ID: <strong><?php echo htmlspecialchars($matric); ?></strong>?</p>
    <form method="POST">
        <input type="hidden" name="matric" value="<?php echo htmlspecialchars($matric); ?>">
        <button type="submit" name="confirm_delete">Yes, Delete</button>
        <a href="user_list.php"><button type="button">Cancel</button></a>
    </form>
</body>
</html>
