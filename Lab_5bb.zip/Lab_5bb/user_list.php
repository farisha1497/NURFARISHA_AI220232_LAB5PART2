<?php
echo '<h1>User List</h1>';
$conn = new mysqli('localhost', 'root', '', 'Lab_5b');
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}
$result = $conn->query("SELECT matric, name, role FROM users");
if ($result->num_rows > 0) {
    echo '<table border="1"><tr><th>Matric</th><th>Name</th><th>Level</th><th>Actions</th></tr>';
    while ($row = $result->fetch_assoc()) {
        echo '<tr><td>' . $row['matric'] . '</td><td>' . $row['name'] . '</td><td>' . $row['role'] . '</td>';
        echo '<td><a href="update.php?matric=' . $row['matric'] . '">Update</a> | <a href="delete.php?matric=' . $row['matric'] . '">Delete</a></td></tr>';
    }
    echo '</table>';
} else {
    echo 'No users found.';
}
$conn->close();
?>