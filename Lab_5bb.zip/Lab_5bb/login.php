<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn = new mysqli('localhost', 'root', '', 'Lab_5b');

    $matric = $_POST['matric'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT password FROM users WHERE matric = ?");
    $stmt->bind_param('s', $matric);
    $stmt->execute();
    $stmt->bind_result($hashedPassword);

    if ($stmt->fetch() && password_verify($password, $hashedPassword)) {
        session_start();
        $_SESSION['loggedin'] = true;
        header('Location: user_list.php');
    } else {
        echo 'Invalid username or password, try <a href="login.php">login</a> again.';
    }

    $stmt->close();
    $conn->close();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>
    <h1>Login</h1><br>
    <form method="POST">
        <label>Matric: </label><input type="text" name="matric" required><br>
        <label>Password: </label><input type="password" name="password" required><br>
        <button type="submit">Login</button>
    </form><br>
    <br>
    <a href="registration.php">Register</a> here if you have not.
</body>
</html>