<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn = new mysqli('localhost', 'root', '', 'Lab_5b');

    if ($conn->connect_error) {
        die('Connection failed: ' . $conn->connect_error);
    }

    $matric = $_POST['matric'];
    $name = $_POST['name'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'];

    $stmt = $conn->prepare("INSERT INTO users (matric, name, password, role) VALUES (?, ?, ?, ?)");
    $stmt->bind_param('ssss', $matric, $name, $password, $role);

    if ($stmt->execute()) {
        echo 'Registration successful!';
    } else {
        echo 'Error: ' . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Registration</title>
</head>
<body>
    <h1>Registration</h1><br>
    <form method="POST">
        <label>Matric: </label><input type="text" name="matric" required><br>
        <label>Name: </label><input type="text" name="name" required><br>
        <label>Password: </label><input type="password" name="password" required><br>
        <label>Role: </label>
        <select name="role">
            <option value="" selected="selected">Please select</option>
            <option value="student">Student</option>
            <option value="lecturer">Lecturer</option>
        </select><br>
        <button type="submit">Submit</button>
    </form>
</body>
</html>

